#include "basis.h"
#include "cca.h"
#include "cw.h"
//#include "InitialAssignment.h"
#include<iostream>
#include<time.h>
#include <fstream>
using namespace std;
/*
#include <sys/times.h> //these two h files are for linux
#include <unistd.h>
*/
int delta_age;

int pick_var_large()
{
	int         i,k,c,v;
	int         best_var;
	lit*		clause_c;

	/**Greedy Mode**/
	/*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
	if(goodvar_stack_fill_pointer>0)
	{
		best_var = goodvar_stack[0];

		for(i=1; i<goodvar_stack_fill_pointer; ++i)
		{
			v=goodvar_stack[i];
			if(score[v]>score[best_var]) best_var = v;

			else if(score[v]==score[best_var])
			{
				if(abs(time_stamp[v]-time_stamp[best_var])<delta_age)
				{
					if(pscore[v]>pscore[best_var])best_var = v;
				}
				else if(time_stamp[v]<time_stamp[best_var])best_var = v;
			}
		}

		return best_var;
	}

	/*SD (significant decreasing) mode, the level with aspiration*/
	best_var = 0;
	for(i=0; i<unsatvar_stack_fill_pointer; ++i)
	{
		if(score[unsatvar_stack[i]]>sigscore)
		{
			best_var = unsatvar_stack[i];
			break;
		}
	}

	for(++i; i<unsatvar_stack_fill_pointer; ++i)
	{
		v=unsatvar_stack[i];
		if(score[v]>score[best_var]) best_var = v;
		else if(score[v]==score[best_var])
		{
			if(abs(time_stamp[v]-time_stamp[best_var])<delta_age)
			{
				if(pscore[v]>pscore[best_var])best_var = v;
			}
			else if(time_stamp[v]<time_stamp[best_var])best_var = v;
		}
	}

	if(best_var!=0) return best_var;

	/**Diversification Mode**/

	update_clause_weights();

	/*focused random walk*/
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	clause_c = clause_lit[c];
	best_var = clause_c[0].var_num;
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v=clause_c[k].var_num;
		if(abs(time_stamp[v]-time_stamp[best_var])<delta_age)
		{
			if(score[v]>score[best_var]) best_var = v;
			else if(score[v]==score[best_var] && pscore[v]>pscore[best_var]) best_var = v;
		}
		else if(time_stamp[v]<time_stamp[best_var]) best_var = v;
	}

	return best_var;
}

//pick a var to be flip
int pick_var_3SAT()
{
	int         i,k,c,v;
	int         best_var;
	lit*		clause_c;
    /**** ke yi siugai ****/
	/**Greedy Mode**/
	/*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
	if(goodvar_stack_fill_pointer>0)
	{
		best_var = goodvar_stack[0];

		for(i=1; i<goodvar_stack_fill_pointer; ++i)
		{
			v=goodvar_stack[i];
			if(score[v]>score[best_var]) best_var = v;
			else if(score[v]==score[best_var] && time_stamp[v]<time_stamp[best_var]) best_var = v;
		}

		return best_var;
	}

	/*SD (significant decreasing) mode, the level with aspiration*/
	best_var = 0;
	for(i=0; i<unsatvar_stack_fill_pointer; ++i)
	{
		if(score[unsatvar_stack[i]]>sigscore)
		{
			best_var = unsatvar_stack[i];
			break;
		}
	}

	for(++i; i<unsatvar_stack_fill_pointer; ++i)
	{
		v=unsatvar_stack[i];
		if(score[v]>score[best_var]) best_var = v;
		else if(score[v]==score[best_var] && time_stamp[v]<time_stamp[best_var]) best_var = v;
	}

	if(best_var!=0) return best_var;

	/**Diversification Mode**/

	update_clause_weights();

	/*focused random walk*/
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	clause_c = clause_lit[c];
	best_var = clause_c[0].var_num;
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v=clause_c[k].var_num;
		if(time_stamp[v]<time_stamp[best_var]) best_var = v;
	}
	
	//flip_var_frequency[best_var]=flip_var_frequency[best_var]+1; //by zhangzaijun

	return best_var;
}


int (* pick_var) ();


//set functions in the algorithm
void set_functions()
{
	set_clause_weighting();

	if(probtype==SAT3||probtype==strSAT)
	{
		flip = flip_3SAT;
		pick_var = pick_var_3SAT;
	}
	else //large ksat
	{
		flip = flip_large;
		pick_var = pick_var_large;

		if(probtype==SAT5)
		{
			delta_age=2*num_vars;
			if(delta_age>2000)delta_age=2000;
		}
		else {
			delta_age=20*num_vars;
			if(delta_age>2500)delta_age=2500;
		}
	}
}

void local_search(int max_flips, double cutTime, clock_t start)
{
	int flipvar;
	clock_t finish;
	double comp_time;
	 
	for (step = 0; step<max_flips; step++)
	{
		//find a solution
        finish = clock();
        comp_time = (double)(finish - start) / CLOCKS_PER_SEC;
		if(unsat_stack_fill_pointer==0 || comp_time>cutTime) return;

		flipvar = pick_var();

		flip(flipvar);

		time_stamp[flipvar] = step;


	}

}


int main(int argc, char* argv[])
{
	int     seed,i;
	double comp_time ;
	double cutTime = 5000;
	cout<<"c this is CCASat"<<endl;

	clock_t start, finish;

	//struct tms start, stop;
	//times(&start);
	start = clock();

	if (build_instance(argv[1])==0)
	{
		cout<<"Invalid filename: "<< argv[1]<<endl;
		return -1;
	}

    //sscanf(argv[2],"%d",&seed);
    srand(time(NULL));

    //srand(seed);

	set_functions();

	for (i = 0; i <= max_tries; i++)
	{
		 init();

		 //times(&stop);

		 local_search(max_flips, cutTime, start);
		 
        finish = clock();
        comp_time = (double)(finish - start) / CLOCKS_PER_SEC;

		 if (unsat_stack_fill_pointer==0 || comp_time>cutTime) break;
	}

	finish = clock();
	comp_time = (double)(finish - start) / CLOCKS_PER_SEC;

	//times(&stop);
	//double comp_time = double(stop.tms_utime - start.tms_utime +stop.tms_stime - start.tms_stime) / sysconf(_SC_CLK_TCK);

	if(unsat_stack_fill_pointer==0)
	{
		if(verify_sol()==1)
		{
			cout<<"s SATISFIABLE"<<endl;
			//print_solution();

			cout<<"c solveSteps = "<<i<<" tries + "<<step<<" steps (each try has 2,000,000,000 steps)."<<endl;
            cout<<"c solveTime = "<<comp_time<<endl;

        }
        else cout<<"c Sorry, something is wrong."<<endl;
    }
    else  cout<<"s UNKNOWN"<<endl;

    free_memory();

    return 0;
}
