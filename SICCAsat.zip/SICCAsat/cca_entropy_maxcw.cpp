#include "basis.h"
#include "cca.h"
#include "cw1.h"

//#include "InitialAssignment.h"
#include<iostream>
#include<time.h>
#include <fstream>

using namespace std;
/*
#include <sys/times.h> //these two h files are for linux
#include <unistd.h>
*/
int delta_age;

int pick_var_large() {
    int         i, k, c, v;
    int         best_var;
    lit*		clause_c;

    /**Greedy Mode**/
    /*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
    if(goodvar_stack_fill_pointer > 0) {
        best_var = goodvar_stack[0];

        for(i = 1; i < goodvar_stack_fill_pointer; ++i) {
            v = goodvar_stack[i];
            if(score[v] > score[best_var])
                best_var = v;

            else if(score[v] == score[best_var]) {
                if(abs(time_stamp[v] - time_stamp[best_var]) < delta_age) {
                    if(pscore[v] > pscore[best_var])
                        best_var = v;
                }
                else if(time_stamp[v] < time_stamp[best_var])
                    best_var = v;
            }
        }

        return best_var;
    }

    /*SD (significant decreasing) mode, the level with aspiration*/
    best_var = 0;
    for(i = 0; i < unsatvar_stack_fill_pointer; ++i) {
        if(score[unsatvar_stack[i]] > sigscore) {
            best_var = unsatvar_stack[i];
            break;
        }
    }

    for(++i; i < unsatvar_stack_fill_pointer; ++i) {
        v = unsatvar_stack[i];
        if(score[v] > score[best_var])
            best_var = v;
        else if(score[v] == score[best_var]) {
            if(abs(time_stamp[v] - time_stamp[best_var]) < delta_age) {
                if(pscore[v] > pscore[best_var])
                    best_var = v;
            }
            else if(time_stamp[v] < time_stamp[best_var])
                best_var = v;
        }
    }

    if(best_var != 0)
        return best_var;

    /**Diversification Mode**/

    update_clause_weights();

    /*focused random walk*/
    c = unsat_stack[rand() % unsat_stack_fill_pointer];
    clause_c = clause_lit[c];
    best_var = clause_c[0].var_num;
    for(k = 1; k < clause_lit_count[c]; ++k) {
        v = clause_c[k].var_num;
        if(abs(time_stamp[v] - time_stamp[best_var]) < delta_age) {
            if(score[v] > score[best_var])
                best_var = v;
            else if(score[v] == score[best_var] && pscore[v] > pscore[best_var])
                best_var = v;
        }
        else if(time_stamp[v] < time_stamp[best_var])
            best_var = v;
    }

    return best_var;
}

//pick a var to be flip
int pick_var_3SAT() {
    int         i, k, c, v;
    int         best_var;
    lit*		clause_c;
    /**** ke yi siugai ****/
    /**Greedy Mode**/
    /*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
    if(goodvar_stack_fill_pointer > 0) {
        best_var = goodvar_stack[0];

        for(i = 1; i < goodvar_stack_fill_pointer; ++i) {
            v = goodvar_stack[i];
            if(score[v] > score[best_var])
                best_var = v;
            else if(score[v] == score[best_var] && time_stamp[v] < time_stamp[best_var])
                best_var = v;
        }

        return best_var;
    }

    /*SD (significant decreasing) mode, the level with aspiration*/
    best_var = 0;
    for(i = 0; i < unsatvar_stack_fill_pointer; ++i) {
        if(score[unsatvar_stack[i]] > sigscore) {
            best_var = unsatvar_stack[i];
            break;
        }
    }

    for(++i; i < unsatvar_stack_fill_pointer; ++i) {
        v = unsatvar_stack[i];
        if(score[v] > score[best_var])
            best_var = v;
        else if(score[v] == score[best_var] && time_stamp[v] < time_stamp[best_var])
            best_var = v;
    }

    if(best_var != 0) {
        return best_var;

    }

    /**Diversification Mode**/

    update_clause_weights();
    //ȡ�����ѡ��ÿ��ѡ������Ȩ����󣬻�����Ϣ��С���־䣬�������ϵı�Ԫ
    int cc = 0;
    int max_c = 0;
    int chose_c;
    int max_c_count = 0;

//    ofstream tva;
//    tva.open("unsat_c.txt", ios::out | ios::app);
//    tva<<"�ܵĲ������Ӿ�����"<<unsat_stack_fill_pointer<<endl;

    for(i = 0; i < unsat_stack_fill_pointer; ++i) {
        cc = unsat_stack[i];

        if(max_c < clause_weight[cc]) {
            max_c_count = 0;
            max_c = clause_weight[cc];
            c = cc;
        }
        else if (max_c == clause_weight[cc]) {
            max_c_count ++;
        }
    }

//      tva<<"���Ȩ���Ӿ�����"<<max_c_count<<endl;

    clause_c = clause_lit[c];
    best_var = clause_c[0].var_num;
    for(k = 1; k < clause_lit_count[c]; ++k) {
        v = clause_c[k].var_num;
        if(time_stamp[v] < time_stamp[best_var] )
            best_var = v;
    }

    if(max_c_count > 0  &&  max_c_count < 15 ) {
        for (int j = 0; j < unsat_stack_fill_pointer; ++j) {
            cc = unsat_stack[j];
            if (max_c == clause_weight[cc] && c != cc) {
                clause_c = clause_lit[cc];
                for(k = 0; k < clause_lit_count[cc]; ++k) {
                    v = clause_c[k].var_num;
                    if(time_stamp[v] < time_stamp[best_var] )
                        best_var = v;
                }
            }
        }

    }

    if(max_c_count > 1000  &&  max_c_count >0.85*num_clauses )
    {
        double max_ccc =100;
        int ccc=0;
        int c1=0;
        for (int j=0; j<unsat_stack_fill_pointer; ++j)
        {
            c1 = unsat_stack[j];

            if (max_ccc>C_entropy[c1])
            {
                max_ccc=C_entropy[c1];
                clause_c = clause_lit[c1];
                ccc=c1;
            }

        }
        best_var = clause_c[0].var_num;
        //double var_entropy = H_entropy[clause_c[0].var_num];
        for(k=1; k<clause_lit_count[ccc]; ++k)
        {
            v=clause_c[k].var_num;
            //if(time_stamp[v]<time_stamp[best_var]) best_var = v;
            if(time_stamp[v]<time_stamp[best_var])
                best_var = v;

        }
    }


//    tva << endl;
//    tva.close();

    return best_var;
}


int (* pick_var) ();


//set functions in the algorithm
void set_functions() {
    set_clause_weighting();

    if(probtype == SAT3 || probtype == strSAT) {
        flip = flip_3SAT;
        pick_var = pick_var_3SAT;
    }
    else { //large ksat
        flip = flip_large;
        pick_var = pick_var_large;

        if(probtype == SAT5) {
            delta_age = 2 * num_vars;
            if(delta_age > 2000)
                delta_age = 2000;
        }
        else {
            delta_age = 20 * num_vars;
            if(delta_age > 2500)
                delta_age = 2500;
        }
    }
}

void local_search(int max_flips, double cutTime, clock_t start)
{
	int flipvar;
	clock_t finish;
	double comp_time;

	for (step = 0; step<max_flips; step++)
	{
		//find a solution
        finish = clock();
        comp_time = (double)(finish - start) / CLOCKS_PER_SEC;
		if(unsat_stack_fill_pointer==0 || comp_time>cutTime) return;

		flipvar = pick_var();

		flip(flipvar);

		time_stamp[flipvar] = step;


	}

}


int main(int argc, char* argv[])
{
	int     seed,i;
	double comp_time ;
	double cutTime = 1000;
	cout<<"c this is CCASat"<<endl;

	clock_t start, finish;

	//struct tms start, stop;
	//times(&start);
	start = clock();

	if (build_instance(argv[1])==0)
	{
		cout<<"Invalid filename: "<< argv[1]<<endl;
		return -1;
	}

    //sscanf(argv[2],"%d",&seed);
    srand(time(NULL));

    //srand(seed);

	set_functions();

	for (i = 0; i <= max_tries; i++)
	{
		 init();

		 //times(&stop);

		 local_search(max_flips, cutTime, start);

        finish = clock();
        comp_time = (double)(finish - start) / CLOCKS_PER_SEC;

		 if (unsat_stack_fill_pointer==0 || comp_time>cutTime) break;
	}

	finish = clock();
	comp_time = (double)(finish - start) / CLOCKS_PER_SEC;

	//times(&stop);
	//double comp_time = double(stop.tms_utime - start.tms_utime +stop.tms_stime - start.tms_stime) / sysconf(_SC_CLK_TCK);

	if(unsat_stack_fill_pointer==0)
	{
		if(verify_sol()==1)
		{
			cout<<"s SATISFIABLE"<<endl;
			//print_solution();

			cout<<"c solveSteps = "<<i<<" tries + "<<step<<" steps (each try has 2,000,000,000 steps)."<<endl;
            cout<<"c solveTime = "<<comp_time<<endl;

        }
        else cout<<"c Sorry, something is wrong."<<endl;
    }
    else  cout<<"s UNKNOWN"<<endl;

    free_memory();

    return 0;
}
