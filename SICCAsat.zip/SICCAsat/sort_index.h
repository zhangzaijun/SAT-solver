#ifndef SORT_INDEX_H_INCLUDED
#define SORT_INDEX_H_INCLUDED

#include <vector>
#include <iostream>
using namespace std;
void BubbleSort(double  *p, int length, int * ind_diff) {
    for (int m = 0; m <= length; m++) {
        ind_diff[m] = m;
    }
    for (int i = 0; i <=length; i++)	{
        for (int j = 0; j <=length - i - 1; j++) {
            if (p[j] > p[j + 1]) {
                float temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
                int ind_temp = ind_diff[j];
                ind_diff[j] = ind_diff[j + 1];
                ind_diff[j + 1] = ind_temp;
            }
        }
    }
}

#endif // SORT_INDEX_H_INCLUDED
